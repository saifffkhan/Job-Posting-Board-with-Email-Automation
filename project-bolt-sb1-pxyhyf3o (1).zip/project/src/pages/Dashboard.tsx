import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';
import { Job } from '../types';
import { Calendar, Users } from 'lucide-react';

const Dashboard = () => {
  const { company } = useAuth();
  const [jobs, setJobs] = useState<Job[]>([]);

  useEffect(() => {
    const fetchJobs = async () => {
      try {
        const response = await axios.get(`http://localhost:5000/api/jobs/company/${company?._id}`);
        setJobs(response.data);
      } catch (error) {
        console.error('Error fetching jobs:', error);
      }
    };

    if (company?._id) {
      fetchJobs();
    }
  }, [company?._id]);

  return (
    <div>
      <h1 className="text-3xl font-bold text-gray-900 mb-8">Your Job Postings</h1>
      
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {jobs.map((job) => (
          <div key={job._id} className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-2">{job.title}</h2>
            <p className="text-gray-600 mb-4 line-clamp-3">{job.description}</p>
            
            <div className="flex items-center text-gray-500 mb-2">
              <Users className="h-4 w-4 mr-2" />
              <span>{job.candidates.length} candidates</span>
            </div>
            
            <div className="flex items-center text-gray-500">
              <Calendar className="h-4 w-4 mr-2" />
              <span>Ends {new Date(job.endDate).toLocaleDateString()}</span>
            </div>
            
            <div className="mt-4 pt-4 border-t">
              <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                ${job.experienceLevel === 'BEGINNER' ? 'bg-green-100 text-green-800' :
                  job.experienceLevel === 'INTERMEDIATE' ? 'bg-yellow-100 text-yellow-800' :
                  'bg-red-100 text-red-800'}`}>
                {job.experienceLevel}
              </span>
            </div>
          </div>
        ))}
      </div>

      {jobs.length === 0 && (
        <div className="text-center py-12">
          <p className="text-gray-500">No job postings yet. Create your first job posting!</p>
        </div>
      )}
    </div>
  );
};

export default Dashboard;