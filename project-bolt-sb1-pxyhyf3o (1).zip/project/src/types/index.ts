export interface Company {
  _id?: string;
  name: string;
  email: string;
  mobile: string;
  isVerified: boolean;
}

export interface Job {
  _id?: string;
  title: string;
  description: string;
  experienceLevel: 'BEGINNER' | 'INTERMEDIATE' | 'EXPERT';
  candidates: string[];
  endDate: string;
  companyId: string;
  createdAt?: string;
}

export interface AuthResponse {
  token: string;
  company: Company;
}