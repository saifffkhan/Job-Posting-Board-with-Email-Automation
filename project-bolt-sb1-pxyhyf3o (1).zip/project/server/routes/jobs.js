import express from 'express';
import jwt from 'jsonwebtoken';
import Job from '../models/Job.js';
import Company from '../models/Company.js';
import { sendJobNotification } from '../utils/emailService.js';

const router = express.Router();

// Middleware to verify JWT token
const auth = async (req, res, next) => {
  try {
    const token = req.header('Authorization')?.replace('Bearer ', '');
    if (!token) {
      return res.status(401).json({ message: 'Authentication required' });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const company = await Company.findById(decoded.id);
    
    if (!company) {
      return res.status(401).json({ message: 'Authentication required' });
    }

    req.company = company;
    next();
  } catch (error) {
    res.status(401).json({ message: 'Authentication required' });
  }
};

// Create a new job
router.post('/', auth, async (req, res) => {
  try {
    const { title, description, experienceLevel, candidates, endDate } = req.body;
    
    const job = new Job({
      title,
      description,
      experienceLevel,
      candidates,
      endDate,
      companyId: req.company._id,
    });

    await job.save();

    // Send email notifications to candidates
    await sendJobNotification(job, candidates, req.company);

    res.status(201).json(job);
  } catch (error) {
    console.error('Create job error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get company's jobs
router.get('/company/:companyId', auth, async (req, res) => {
  try {
    const jobs = await Job.find({ companyId: req.params.companyId })
      .sort({ createdAt: -1 });
    res.json(jobs);
  } catch (error) {
    console.error('Get jobs error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

export default router;