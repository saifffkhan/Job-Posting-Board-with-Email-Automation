import express from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import crypto from 'crypto';
import Company from '../models/Company.js';
import { sendVerificationEmail } from '../utils/emailService.js';

const router = express.Router();

router.post('/register', async (req, res) => {
  try {
    const { name, email, password, mobile } = req.body;

    // Check if company already exists
    const existingCompany = await Company.findOne({ email });
    if (existingCompany) {
      return res.status(400).json({ message: 'Email already registered' });
    }

    // Hash password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    // Generate verification token
    const verificationToken = crypto.randomBytes(32).toString('hex');

    // Create new company
    const company = new Company({
      name,
      email,
      password: hashedPassword,
      mobile,
      verificationToken,
    });

    await company.save();

    // Send verification email
    await sendVerificationEmail(email, verificationToken);

    res.status(201).json({ message: 'Registration successful. Please check your email for verification.' });
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    // Find company
    const company = await Company.findOne({ email });
    if (!company) {
      return res.status(400).json({ message: 'Invalid credentials' });
    }

    // Check password
    const isMatch = await bcrypt.compare(password, company.password);
    if (!isMatch) {
      return res.status(400).json({ message: 'Invalid credentials' });
    }

    // Check verification
    if (!company.isVerified) {
      return res.status(400).json({ message: 'Please verify your email first' });
    }

    // Generate JWT
    const token = jwt.sign(
      { id: company._id },
      process.env.JWT_SECRET,
      { expiresIn: '1d' }
    );

    // Remove password from response
    const companyData = company.toObject();
    delete companyData.password;
    delete companyData.verificationToken;

    res.json({ token, company: companyData });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

router.get('/verify/:token', async (req, res) => {
  try {
    const company = await Company.findOne({ verificationToken: req.params.token });
    if (!company) {
      return res.status(400).json({ message: 'Invalid verification token' });
    }

    company.isVerified = true;
    company.verificationToken = undefined;
    await company.save();

    res.json({ message: 'Email verified successfully' });
  } catch (error) {
    console.error('Verification error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

export default router;