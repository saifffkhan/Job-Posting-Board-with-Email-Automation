import nodemailer from 'nodemailer';
import dotenv from 'dotenv';

dotenv.config();

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
});

export const sendVerificationEmail = async (email, token) => {
  const verificationLink = `${process.env.FRONTEND_URL}/verify/${token}`;
  
  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: email,
    subject: 'Verify Your Email',
    html: `
      <h1>Welcome to JobBoard!</h1>
      <p>Please click the link below to verify your email address:</p>
      <a href="${verificationLink}">Verify Email</a>
    `,
  };

  return transporter.sendMail(mailOptions);
};

export const sendJobNotification = async (job, candidates, company) => {
  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: candidates.join(', '),
    subject: `New Job Opportunity: ${job.title}`,
    html: `
      <h1>New Job Opportunity</h1>
      <h2>${job.title}</h2>
      <p><strong>Company:</strong> ${company.name}</p>
      <p><strong>Experience Level:</strong> ${job.experienceLevel}</p>
      <p><strong>Description:</strong></p>
      <p>${job.description}</p>
      <p><strong>Application Deadline:</strong> ${new Date(job.endDate).toLocaleDateString()}</p>
    `,
  };

  return transporter.sendMail(mailOptions);
};